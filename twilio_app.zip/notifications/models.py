from django.db import models
from django.utils.translation import gettext_lazy as _
from django.conf import settings
from django.utils import timezone
from django.core.mail import send_mail
from notification_templates.models import EmailTemplate, SMSTemplate, VoiceTemplate
from twilio.rest import Client

# Initialize Twilio client using credentials from settings
client = Client(settings.TWILIO_ACCOUNT_SID, settings.TWILIO_AUTH_TOKEN)


class NotificationMethod(models.Model):
    """
    Model to define types of notification methods (e.g., Email, SMS, Voice Call).
    """
    METHOD_CHOICES = (
        ('email', _("Email")),
        ('sms', _("SMS")),
        ('voice', _("Voice Call")),
    )
    method = models.CharField(_("Notification Method"), max_length=20, choices=METHOD_CHOICES, unique=True)
    description = models.TextField(_("Description"), blank=True)

    class Meta:
        verbose_name = _("Notification Method")
        verbose_name_plural = _("Notification Methods")

    def __str__(self):
        return self.method


class Notification(models.Model):
    """
    Model to log and manage all notifications sent to users.
    """
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="notifications",
                             verbose_name=_("User"))
    rule = models.ForeignKey("NotificationRule", on_delete=models.SET_NULL, null=True, related_name="notifications",
                             verbose_name=_("Notification Rule"))
    method = models.ForeignKey(NotificationMethod, on_delete=models.SET_NULL, null=True, related_name="notifications",
                               verbose_name=_("Notification Method"))
    status = models.CharField(_("Status"), max_length=20, choices=[('sent', _("Sent")), ('failed', _("Failed")),
                                                                   ('pending', _("Pending"))], default='pending')
    sent_at = models.DateTimeField(_("Sent At"), null=True, blank=True)
    message_id = models.CharField(_("Message ID"), max_length=100, blank=True)
    additional_data = models.JSONField(_("Additional Data"), null=True, blank=True)
    created_at = models.DateTimeField(_("Created At"), auto_now_add=True)

    class Meta:
        verbose_name = _("Notification")
        verbose_name_plural = _("Notifications")
        indexes = [
            models.Index(fields=['user']),
            models.Index(fields=['status']),
        ]

    def __str__(self):
        return f"Notification to {self.user.email if self.user else 'Unknown User'}"

    def send_notification(self):
        """
        Method to send the notification based on the selected method.
        """
        if self.method.method == 'email':
            self.send_email_notification()
        elif self.method.method == 'sms':
            self.send_sms_notification()
        elif self.method.method == 'voice':
            self.send_voice_notification()

    def send_email_notification(self):
        """
        Send email using the selected template and user preferences.
        """
        if self.rule.email_template:
            subject = self.rule.email_template.subject
            body = self.rule.email_template.html_body
            try:
                send_mail(subject, body, settings.DEFAULT_FROM_EMAIL, [self.user.email])
                self.status = 'sent'
            except Exception as e:
                self.status = 'failed'
                self.additional_data = {"error": str(e)}
            finally:
                self.sent_at = timezone.now()
                self.save()

    def send_sms_notification(self):
        """
        Send SMS using Twilio and the selected template and user preferences.
        """
        if self.rule.sms_template:
            try:
                message = client.messages.create(
                    body=self.rule.sms_template.body,
                    from_=settings.TWILIO_PHONE_NUMBER,
                    to=self.user.profile.phone_number  # Assuming the phone number is in the Profile model
                )
                self.message_id = message.sid
                self.status = 'sent'
            except Exception as e:
                self.status = 'failed'
                self.additional_data = {"error": str(e)}
            finally:
                self.sent_at = timezone.now()
                self.save()

    def send_voice_notification(self):
        """
        Make a voice call using Twilio and play the recorded message.
        """
        if self.rule.voice_template:
            try:
                call = client.calls.create(
                    twiml=f'<Response><Play>{self.rule.voice_template.message_file.url}</Play></Response>',
                    from_=settings.TWILIO_PHONE_NUMBER,
                    to=self.user.profile.phone_number  # Assuming the phone number is in the Profile model
                )
                self.message_id = call.sid
                self.status = 'sent'
            except Exception as e:
                self.status = 'failed'
                self.additional_data = {"error": str(e)}
            finally:
                self.sent_at = timezone.now()
                self.save()
